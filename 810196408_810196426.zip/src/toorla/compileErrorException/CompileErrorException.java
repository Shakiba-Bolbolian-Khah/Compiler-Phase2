package toorla.compileErrorException;

public abstract class CompileErrorException extends Exception{
}
