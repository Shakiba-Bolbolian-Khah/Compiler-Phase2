package toorla.ast.statement;

import toorla.visitor.Visitor;

public class Break extends Statement {

    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }

    @Override
    public String toString() {
        return "(Break)";
    }
}