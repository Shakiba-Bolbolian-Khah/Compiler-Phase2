package toorla.ast.statement;

import toorla.ast.Tree;

public abstract class Statement extends Tree {
    abstract public String toString();
}