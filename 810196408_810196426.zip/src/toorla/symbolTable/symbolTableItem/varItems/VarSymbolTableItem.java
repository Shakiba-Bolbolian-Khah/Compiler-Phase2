package toorla.symbolTable.symbolTableItem.varItems;

import toorla.symbolTable.symbolTableItem.SymbolTableItem;

public abstract class VarSymbolTableItem extends SymbolTableItem {
}
